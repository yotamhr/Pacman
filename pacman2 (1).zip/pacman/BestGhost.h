#pragma once
#include "ghost.h"

class BestGhost:public Ghost
{
public:

	void ghostMove();
};

