#pragma once
class point
{
private:
	int _x;
	int _y;

public:
	void setX(int x);
	void setY(int y);
	int getX() const;
	int getY() const;
};

