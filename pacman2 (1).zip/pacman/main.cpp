#include "game.h"

int main()
{
	Game game;
	game.menu();
	return 1;
}