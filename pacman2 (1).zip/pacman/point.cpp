#include "point.h"

int point::getX() const
{
	return _x;
}

int point::getY() const
{
	return _y;
}

void point::setX(int x)
{
	_x = x;
}

void point::setY(int y)
{
	_y = y;
}