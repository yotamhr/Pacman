#pragma once
#include "ghost.h"

class NoviceGhost:public Ghost
{

public:
	void ghostMove();

};

